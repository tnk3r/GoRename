                                           _                             _   _____           
                  _ __ ___ _ __ ___   ___ | |_ ___         ___ _   _ ___| |_|___ /_ __ ___  
                 | '__/ _ \ '_ ` _ \ / _ \| __/ _ \      / __| | | / __| __| |_ \| '_ ` _ \ 
                 | | |  __/ | | | | | (_) | ||  __/   _  \__ \ |_| \__ \ |_ ___) | | | | | |
                 |_|  \___|_| |_| |_|\___/ \__\___|  (_) |___/\__, |___/\__|____/|_| |_| |_|  
                                                              |___/           	                                                                  

					

			// GO PRO RENAME SCRIPT // 
								
				v .6 alpha


		THIS SCRIPT ASSUMES THE NORMAL DIRECTORY STRUCTURE OF GO PRO FILES
		YOU MAY SELECT A 'PARENT' FOLDER FOR RENAME OR A 'NO NAME' MEDIA CARD
		IF YOU HAVE ALREADY RENAMED YOUR MEDIA I DO NOT SUGGEST RUNNING THIS SCRIPT
		TRY IT OUT TO SEE IF IT FITS IN YOUR WORKFLOW
		FOR BEST RESULTS USE ON MEDIA DIRECTLY BEFORE COPYING TO DISK
		FOLDERS WORK WELL, DEPENDING ON YOUR DIRECTORY STRUCTURE LAYOUT
		PLEASE TRY NOT TO USE SPACES, THEY WILL WORK. BUT HIGHLY DISCOURAGED
		KEEP IN MIND ANY FILE NAMES WITH SPACES IN THEM ARE NOT PROFESSIONAL
						


		INSTALLATION:
		copy the files inside the supplied .DMG into your /Applications Folder 
		Then you can double click on the go-rename file to open the Dialog 
		You must install the supplied Cocoa DIALOG .app (DO NOT TRY TO RUN IT DIRECTLY)
		YOU CAN EMAIL ME AT remote.syst3m@gmail.com FOR QUESTIONS





		USE AT YOUR OWN RISK
		YOU HAVE BEEN WARNED		
								
			&&
								
	  	Homie Don't Right Click!




UPDATES:  v .6

FIXED VARIOUS FOLDER CHECKING ISSUES. 
ADDED LOGGING RENAMED CLIPS
CHANGED ENUM FOR VOLUMES/MEDIA FOR SPECIAL CASES



 ===================================================================================================================

